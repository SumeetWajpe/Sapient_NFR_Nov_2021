let cacheName = "v5";
let cacheAssets = [
  "Index.html",
  "About.html",
  "js/script.js",
  "css/styles.css",
];

// install event
self.addEventListener("install", function (e) {
  console.log("Service Worker : Installed !");
  e.waitUntil(
    caches
      .open(cacheName)
      .then(function (cache) {
        console.log("Service Worker : Caching Files !");
        cache.addAll(cacheAssets);
      })
      .then(function () {
        self.skipWaiting(); // activates the service worker
      })
  );
});

self.addEventListener("activate", function (e) {
  console.log("Service Worker : Activated !");
  e.waitUntil(
    caches.keys().then(function (cacheNames) {
      return Promise.all(
        cacheNames.map(function (cache) {
          if (cache !== cacheName) {
            console.log("Deleting Old Cache !");
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

self.addEventListener("fetch", function (e) {
  console.log("Service Worker : Fetching!");
  e.respondWith(
    fetch(e.request).catch(function () {
      return caches.match(e.request);
    })
  );
});
