let allCourses;

function FetchCourses() {
  return fetch("http://localhost:5000/courses").then((res) => res.json());
}

function DisplayCourses() {
  let coursePromise = FetchCourses();
  coursePromise.then((courses) => {
    allCourses = courses;
    for (let eachcourse of allCourses) {
      CourseItem(eachcourse);
    }
  });
}

function CourseItem(course) {
  let courseItem = document.createElement("div");
  courseItem.setAttribute("class", "col-md-3");

  let courseCard = document.createElement("div");
  courseCard.setAttribute("class", "card m-1 p-2");

  let courseImage = document.createElement("img");
  courseImage.setAttribute("src", course.imageUrl);
  courseImage.setAttribute("alt", course.title);
  courseImage.setAttribute("height", "150px");

  courseImage.setAttribute("class", "card-img-top");

  courseCard.append(courseImage);

  let courseCardBody = document.createElement("div");
  courseCardBody.setAttribute("class", "card-body");

  let courseRating = document.createElement("div");

  for (i = 0; i < course.rating; i++) {
    courseRating.innerHTML +=
      '<span style="color: Dodgerblue;" > <i class="fas fa-star"></i></span>';
  }

  courseCardBody.appendChild(courseRating);

  // title
  let courseTitle = document.createElement("h5");
  courseTitle.setAttribute("class", "card-title");
  courseTitle.innerHTML = course.title;
  courseCardBody.append(courseTitle);
  //price
  let coursePrice = document.createElement("h5");
  coursePrice.setAttribute("class", "card-text");
  coursePrice.innerHTML += "₹." + course.price;
  courseCardBody.append(coursePrice);

  // likes
  let courseLikes = document.createElement("button");
  courseLikes.setAttribute("class", "btn btn-primary");
  courseLikes.innerHTML = course.likes;

  // let courseLikesIcon = document.createElement('i');
  // courseLikesIcon.setAttribute('class', 'far fa-thumbs-up');
  courseLikes.innerHTML += '<i class="far fa-thumbs-up"></i>';

  // delete
  let courseDelete = document.createElement("button");
  courseDelete.setAttribute("class", "btn btn-danger mx-1");
  courseDelete.setAttribute("id", course.id);

  courseDelete.innerHTML = '<i class="fa fa-trash"></i>';
  courseDelete.addEventListener("click", DeleteCourseHandler);

  courseCardBody.append(courseLikes);
  courseCardBody.append(courseDelete);

  courseCard.append(courseCardBody);
  courseItem.append(courseCard);

  document.querySelector("#courseslist").append(courseItem);
}

function DeleteCourseHandler(e) {
  let theCourseId;
  if (e.target.nodeName === "I") {
    theCourseId = e.target.parentNode.id;
  } else {
    theCourseId = e.target.id;
  }

  fetch("/courses/" + theCourseId, {
    method: "DELETE",
    //body: JSON.parse({ key: 1, value: 2 }),
    // headers:{'Content-Type':'application/json'}
  })
    .then((res) => {
      if (res.ok) return res.json();
    }) // response.ok
    .then((success) => {
      if (success.msg === "success") {
        alert("Deleting course..");
        // delete the course from DOM here
        window.location.href = "/";
      }
    });
}
