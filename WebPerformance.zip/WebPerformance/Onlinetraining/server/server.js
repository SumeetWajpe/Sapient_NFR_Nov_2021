var express = require("express"); // importing
var app = express();
var path = require("path");
const courses = require("../model/courselist.model");
const fs = require("fs");

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "static")));
app.use(express.json());

// app.get("/", (req, res) => res.sendFile("TheForm.html", { root: __dirname }));
app.get("/", (req, res) => res.sendFile("Courses.html", { root: __dirname }));

app.post("/login", (req, res) => {
  console.log(req.body);
  res.send(`${req.body.uName} , Submitted successfully !`);
});

app.get("/courses", (req, res) => {
  res.json(courses);
});

app.delete("/courses/:id", (req, res) => {
  // use filter
  // let newCourseList = courses.filter((course) => course.id !== +req.params.id);
  // courses = newCourseList;

  let theIndex = courses.findIndex((c) => c.id === +req.params.id);
  courses.splice(theIndex, 1);

  res.json({ msg: "success" });
});

app.post("/newcourse", (req, res) => {
  // get the values from the request object
  // add new course to courses array
  let newCourse = req.body;
  courses.push(newCourse);

  // storing the data in .json / db
  let courses_json = JSON.stringify(courses);
  fs.writeFile("Courses.json", courses_json, function (err) {
    if (err) console.log(err);
    else console.log("File created successfully !");
  });
  res.json({ msg: "added" });
});

/* 404 or any other request !*/
app.use(function (req, res) {
  res.send("<h1 style='color:red'> Resource not Found ! 404 ! </h1>");
});
app.listen(5000, () => console.log("Server running at port 5000 !"));
